﻿Public Class Form1
    ' Here I use Array to store past loan calculations
    Private loanCalculations As New List(Of String)()

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' These are Variables to store user input
        Dim loanAmount As Double
        Dim loanTerm As Integer
        Dim interestRate As Double

        ' This part of the code will Read inputs from TextBoxes
        If Not Double.TryParse(txtLoanAmount.Text, loanAmount) OrElse loanAmount <= 0 Then
            MessageBox.Show("Please enter a valid loan amount.")
            Exit Sub
        End If

        If Not Integer.TryParse(txtLoanTerm.Text, loanTerm) OrElse loanTerm <= 0 Then
            MessageBox.Show("Please enter a valid loan term in months.")
            Exit Sub
        End If

        If Not Double.TryParse(txtInterestRate.Text, interestRate) OrElse interestRate <= 0 Then
            MessageBox.Show("Please enter a valid annual interest rate.")
            Exit Sub
        End If

        ' Here I am Converting annual interest rate to monthly and decimal.
        Dim monthlyRate As Double = (interestRate / 100) / 12

        ' This is the Calculation of monthly payment using the formula.
        ' The formula used here is the standard amortization formula to calculate monthly payments for a loan:
        ' Monthly Payment = [P * r * (1 + r)^n] / [(1 + r)^n - 1]
        ' Where:
        ' P = loan amount (principal)
        ' r = monthly interest rate (annual interest rate / 12)
        ' n = loan term in months
        ' The formula calculates the fixed monthly payment required to pay off a loan of amount P over n months, 
        ' considering a monthly interest rate r.
        Dim numerator As Double = loanAmount * monthlyRate * Math.Pow(1 + monthlyRate, loanTerm)
        Dim denominator As Double = Math.Pow(1 + monthlyRate, loanTerm) - 1

        If denominator > 0 Then
            Dim monthlyPayment As Double = numerator / denominator
            lblResult.Text = "Monthly Payment: $" & Math.Round(monthlyPayment, 2).ToString()

            'I am Storing the calculation here in the list below.
            StoreCalculation(loanAmount, loanTerm, interestRate, monthlyPayment)
        Else
            lblResult.Text = "Invalid calculation."
        End If
    End Sub

    ' Stored the calculation in the list
    Private Sub StoreCalculation(loanAmount As Double, loanTerm As Integer, interestRate As Double, monthlyPayment As Double)
        'I am converting the monthly payment to a string and store it
        Dim calculationDetail As String = $"Monthly Payment: ${Math.Round(monthlyPayment, 2)}"

        'I have add previous calculations to the list.
        loanCalculations.Add(calculationDetail)

        'Here I am Displaying stored calculations.
        DisplayCalculations()
    End Sub

    ' Display all stored calculations
    Private Sub DisplayCalculations()
        lstCalculations.Items.Clear()
        For Each calculation As String In loanCalculations
            lstCalculations.Items.Add(calculation)
        Next
    End Sub

    'This is the Clear button event handler
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear TextBoxes and result label
        txtLoanAmount.Clear()
        txtLoanTerm.Clear()
        txtInterestRate.Clear()
        lblResult.Text = "Monthly Payment: $"
        lstCalculations.Items.Clear()
        loanCalculations.Clear() ' Reset list
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub lstCalculations_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstCalculations.SelectedIndexChanged

    End Sub
End Class
